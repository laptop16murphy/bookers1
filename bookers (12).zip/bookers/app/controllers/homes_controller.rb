class HomesController < ApplicationController
  def index
    @book = Book.all
  end
end
